import { dispatch } from 'src/reducers/configureStore';
import { setHideBeatLoader, setShowBeatLoader } from 'src/reducers/slices/AlertsSlice';
import axios from '../utils/axios';
import { errorToast } from 'src/shared/Toast';

export const TechnicalDataListing = async () => {
  try {
    dispatch(setShowBeatLoader());
    const { data } = await axios.get('/api/data/get-device-models-all');
    if (data?.status) {
      return data?.data;
    } else {
      errorToast(data?.message);
    }
  } catch (error) {
    errorToast('Listing failed');

    console.error('Listing failer failed', error);
  } finally {
    dispatch(setHideBeatLoader());
  }
};
