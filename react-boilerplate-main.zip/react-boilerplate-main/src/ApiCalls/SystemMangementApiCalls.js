import axios from 'src/utils/axios';
import { dispatch } from 'src/reducers/configureStore';
import { setAuthData } from 'src/reducers/slices/AuthSLice';
import { errorToast, successToast } from 'src/shared/Toast';
import moment from 'moment';
import { setHideBeatLoader, setShowBeatLoader } from 'src/reducers/slices/AlertsSlice';

const systemFormatter = (system) => {
  return {
    id: system.id,
    email: system.email,
    deviceName: system.deviceName,
    serialNumber: system.serial_number,
    servicePartner: system.service_partner_id,
    customerName: system.name,
    modelNumber: system.model_number,
    wifiModuleAddress: system.wifi_module_address,
    MACAddress: system.mac_address,
    activationDate: system.uploadDate,
    uploadDate: moment(system.created_at).format('MM-DD-YYYY'),
    batteryStatus: system.battery_status,
  };
};

const systemsFormatter = (systems) => {
  return systems.map((system) => systemFormatter(system));
};

export const createSystem = async (values) => {
  const payload = {
    serial_number: values.serialNumber,
    mac_address: values.macAddress,
    model_number: values.modelNumber,
    service_partner_id: values.authorizedPartner,
  };
  try {
    const { data } = await axios.post('/api/device/', payload);

    if (data?.status) {
      successToast(data.message);
      return true;
    } else {
      errorToast(data.errors[0].message);
    }
  } catch (error) {
    console.log('error', error);
    errorToast('Something went wrong!');
  }
};

export const ListSystems = async (e) => {
  try {
    dispatch(setShowBeatLoader());
    const { data } = await axios.get('api/device/listing');
    if (data?.status) {
      return systemsFormatter(data?.data);
    } else {
      errorToast(data.message);
    }
  } catch (error) {
    errorToast('Listing failed');

    console.error('Listing failer failed', error);
  } finally {
    dispatch(setHideBeatLoader());
  }
};

export const deleteSystem = async (systemID) => {
  try {
    dispatch(setShowBeatLoader());
    const response = await axios.delete(`/api/device/${systemID}`);
    if (response?.data?.status) {
      successToast(response?.data?.message ?? 'Device Deleted Successfully');
      return true;
    } else {
      errorToast(response?.data?.message);
    }
  } catch (e) {
    console.error(e);
    errorToast('An error occurred while deleting the script');
  } finally {
    dispatch(setHideBeatLoader());
  }
};

export const editSystem = async (values, systemID) => {
  const payload = {
    serial_number: values.serialNumber,
    mac_address: values.macAddress,
    model_number: values.modelNumber,
    service_partner_id: values.authorizedPartner,
  };
  try {
    const { data } = await axios.put(`/api/device/${systemID}`, payload);

    if (data?.status) {
      dispatch(setAuthData(data?.data));
      successToast(data.message);
      return true;
    } else {
      errorToast(data.message);
    }
  } catch (error) {
    console.log('error', error);
    errorToast('Something went wrong!');
  }
};
