import axios from '../utils/axios';
import { get } from 'lodash';

export const uploadList = async (data) => {
  try {
    const payload = {
      servicePartners: data,
    };
    const updateResponse = await axios.post(`/api/service-partners/import`, payload);
    return get(updateResponse, 'data', false);
  } catch (error) {
    return false;
  }
};
