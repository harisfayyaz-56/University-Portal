// OT USING TILL YET AS NO DASHBOARD IS USED Currenlty

// import React from 'react';
// import { Typography, Box } from '@mui/material';
// import PageContainer from 'src/components/container/PageContainer';
// import { useSelector } from 'react-redux';

// const Dashboard = () => {
//   const authData = useSelector((state) => state.Auth.authData);

//   return (
//     <PageContainer title="Admin - Dashboard" description="this is Dashboard">
//       {authData ? (
//         <Typography variant="h2" sx={{ textAlign: 'center', py: 4 }}>
//           Welcome{' '}
//           <Box sx={{ marginTop: 1 }}>
//             <Typography component="span" variant="h2" color="primary">
//               {authData.name}
//             </Typography>
//           </Box>
//         </Typography>
//       ) : (
//         <></>
//       )}
//     </PageContainer>
//   );
// };

// export default Dashboard;
