import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import ActionRenderer from './AuthorizedServicePartnerActionRenderer';
import StatusRenderer from '../../shared/StatusRenderer';
import { AuthorizedServicePartnerColumnDefs } from '../utilities/helpers';
import { ListPartners } from 'src/ApiCalls/AuthorizedServicePartnerApiCalls';
import { useEffect, useState } from 'react';

const defaultColDef = {
  flex: 1,
  minWidth: 100,
  sortable: true,
  filter: true,
  resizable: true,
  wrapText: true,
  autoHeight: true,
  cellStyle: { display: 'flex', alignItems: 'center', fontFamily: 'Poppins, sans-serif' },
};
const frameworkComponents = {
  ActionRenderer,
  StatusRenderer,
};

const AuthorizedServicePartnerTable = ({ rows }) => {
  const [ServicePartnerData, setServicePartnerData] = useState(null);

  useEffect(() => {
    (async () => {
      let result = await ListPartners();
      setServicePartnerData(result);
    })();
  }, []);

  return (
    <div className="ag-theme-alpine" style={{ margin: '10px 0', height: '60vh' }}>
      <AgGridReact
        rowData={ServicePartnerData}
        defaultColDef={defaultColDef}
        columnDefs={AuthorizedServicePartnerColumnDefs}
        suppressScrollOnNewData={true}
        rowSelection="single"
        components={frameworkComponents}
      />
    </div>
  );
};

export default AuthorizedServicePartnerTable;
