import React from 'react';
import { Box, Button, Typography } from '@mui/material';
import PageContainer from 'src/components/container/PageContainer';
import AuthorizedServicePartnerTable from './AuthorizedServicePartnerTable';
import { Link } from 'react-router-dom';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
const AuthorizedServicePartner = () => {
  return (
    <PageContainer
      title="Authorized Service Partner"
      description="this is Authorized Service Partner"
    >
      <Box
        component="div"
        display="flex"
        flexDirection={{ xs: 'column', sm: 'row' }}
        justifyContent={{ xs: 'flex-start', sm: 'space-between' }}
        alignItems={{ xs: 'start', sm: 'end' }}
      >
        <Box component="div" mb={{ xs: 2, sm: 0 }}>
          <Typography variant="h3">Authorized Service Partner</Typography>
        </Box>
        <Box component="div">
          <Button
            size="medium"
            sx={{ marginRight: 1 }}
            color="primary"
            component={Link}
            variant="contained"
            to="/service-partner/bulk-upload"
            startIcon={<AddOutlinedIcon />}
          >
            Bulk Upload
          </Button>
          <Button
            size="medium"
            component={Link}
            to="/service-partner/add-service-partner"
            color="primary"
            variant="contained"
            startIcon={<AddOutlinedIcon />}
          >
            Add Partner
          </Button>
        </Box>
      </Box>
      <Box sx={{ mt: 6 }}>
        <AuthorizedServicePartnerTable />
      </Box>
    </PageContainer>
  );
};

export default AuthorizedServicePartner;
