import React, { useCallback, useEffect, useState } from 'react';
import TextField from '@mui/material/TextField';
import {
  Box,
  Typography,
  Button,
  RadioGroup,
  FormControlLabel,
  Radio,
  Avatar,
  MenuItem,
  Select,
} from '@mui/material';
import Grid from '@mui/material/Grid';
import IconButton from '@mui/material/IconButton';
import AddIcon from '@mui/icons-material/Add';
import CheckIcon from '@mui/icons-material/Check';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useLocation, useNavigate, useParams } from 'react-router';
import {
  createPartner,
  editPartner,
  getCities,
  getStates,
} from 'src/ApiCalls/AuthorizedServicePartnerApiCalls';

const countries = [{ label: 'United States', value: 95 }];

const AuthorizedServicePartnerForm = () => {
  const [states, setStates] = useState([]);
  const [cities, SetCities] = useState([]);
  const [partnerData, setPartnerData] = useState({});
  const { state } = useLocation();
  const { id: userId } = useParams();
  const navigate = useNavigate();

  const getPartnerData = useCallback(async (data) => {
    setPartnerData(data);
    const result = await getStates();
    if (result) {
      setStates(result);
    }
    const cities = await getCities(data?.state_id);
    if (cities) {
      SetCities(cities);
    }
  }, []);
  useEffect(() => {
    if (userId) {
      getPartnerData(state);
    }
  }, [getPartnerData, userId, state]);

  const handleSubmitForm = async (values) => {
    let response;
    if (userId) {
      response = await editPartner(values, userId);
    } else {
      response = await createPartner(values);
    }
    if (response) {
      navigate('/service-partner');
    }
  };

  const handleCountryOpen = async (event) => {
    const selectedCountry = event.target?.value;
    formik.setFieldValue('country', selectedCountry);

    const result = await getStates();
    setStates(result);
  };
  const handleStatesOpen = async (event) => {
    const selectedState = event.target?.value;
    formik.setFieldValue('state', selectedState);
    const result = await getCities(selectedState);
    SetCities(result);
  };

  const validateMaxLength = (fieldName, maxLength) =>
    Yup.string().max(maxLength, `${fieldName} must be at most ${maxLength} characters`);

  const validationSchema = Yup.object().shape({
    companyName: validateMaxLength('Company name', 100).required('Company name is required'),
    companyEmail: validateMaxLength('Email', 30)
      .email('Invalid email address')
      .required('Email is required'),
    companyPhone: Yup.string()
      .matches(/^\d+$/, 'Phone number must contain only digits')
      .min(11, 'Phone number must be at least 11 digits')
      .max(15, 'Phone number must be at most 15 digits')
      .required('Phone number is required'),
    is_active: Yup.boolean().optional(),
    city: Yup.string().required('City is required'),
    state: Yup.string().required('State is required'),
    country: Yup.string().required('Country is required'),
  });

  const formik = useFormik({
    enableReinitialize: true,
    initialValues: {
      companyName: partnerData.company_name ?? '',
      companyEmail: partnerData.email ?? '',
      companyPhone: partnerData.phone_number ?? '',
      is_active: partnerData.is_active ?? false,
      logo: partnerData.logo ?? { url: '', file: null },
      city: partnerData.city_id ?? '',
      state: partnerData.state_id ?? '',
      country: partnerData.country_id ?? '',
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      handleSubmitForm(values);
    },
  });

  const handleReset = () => {
    navigate('/service-partner');
  };

  const handleImageChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        formik.setFieldValue('logo', {
          url: reader.result,
          file,
        });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <form onSubmit={formik.handleSubmit}>
      <Box
        sx={{
          bgcolor: '#ffffff',
          marginTop: { xs: 4, sm: 8 },
          padding: { xs: 3, sm: 6 },
          borderRadius: 6,
          position: 'relative',
        }}
      >
        <Typography variant="h3">{!userId ? 'Add Partner' : 'Update Partner'}</Typography>
        <Grid container spacing={2} sx={{ mt: 2 }}>
          <Grid item xs={12} sm={6}>
            <Typography sx={{ color: 'black', fontWeight: '450', mb: 1 }}>Company Name:</Typography>
            <TextField
              fullWidth
              id="companyName"
              variant="outlined"
              value={formik.values?.companyName}
              onChange={formik.handleChange('companyName')}
              error={formik.touched.companyName && Boolean(formik.errors.companyName)}
              helperText={formik.touched.companyName && formik.errors.companyName}
              sx={{ mt: 2 }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <Typography sx={{ color: 'black', fontWeight: '450', mb: 1 }}>
              Company Email:
            </Typography>
            <TextField
              fullWidth
              id="companyEmail"
              type="email"
              variant="outlined"
              value={formik.values?.companyEmail}
              onChange={formik.handleChange('companyEmail')}
              error={formik.touched.companyEmail && Boolean(formik.errors.companyEmail)}
              helperText={formik.touched.companyEmail && formik.errors.companyEmail}
              sx={{ mt: 2 }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <Typography sx={{ color: 'black', fontWeight: '450', mb: 1 }}>
              Company Phone:
            </Typography>
            <TextField
              fullWidth
              id="companyPhone"
              variant="outlined"
              value={formik.values?.companyPhone}
              onChange={formik.handleChange('companyPhone')}
              error={formik.touched.companyPhone && Boolean(formik.errors.companyPhone)}
              helperText={formik.touched.companyPhone && formik.errors.companyPhone}
              sx={{ mt: 2 }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <Typography sx={{ color: 'black', fontWeight: '450', mb: 1 }}>Country:</Typography>
            <Select
              fullWidth
              id="country"
              name="country"
              variant="outlined"
              value={formik.values?.country}
              error={formik.touched.country && Boolean(formik.errors.country)}
              onChange={handleCountryOpen}
              sx={{ mt: 2 }}
            >
              <MenuItem value="">Select Country</MenuItem>
              {countries.map((country) => (
                <MenuItem key={country.value} value={country.value}>
                  {country.label}
                </MenuItem>
              ))}
            </Select>
            {formik.touched.country && formik.errors.country ? (
              <Typography variant="caption" color="error">
                {formik.errors.country}
              </Typography>
            ) : null}
          </Grid>
          <Grid item xs={12} sm={6}>
            <Typography sx={{ color: 'black', fontWeight: '450', mb: 1 }}>State:</Typography>
            <Select
              fullWidth
              id="state"
              variant="outlined"
              value={states?.length ? formik.values?.state : ''}
              disabled={!states?.length}
              onChange={handleStatesOpen}
              error={formik.touched.state && Boolean(formik.errors.state)}
              sx={{ mt: 2 }}
            >
              <MenuItem value="">Select State</MenuItem>
              {states?.map((state) => (
                <MenuItem key={state.id} value={state.id}>
                  {state.name}
                </MenuItem>
              ))}
            </Select>
            {formik.touched.state && formik.errors.state ? (
              <Typography variant="caption" color="error">
                {formik.errors.state}
              </Typography>
            ) : null}
          </Grid>
          <Grid item xs={12} sm={6}>
            <Typography sx={{ color: 'black', fontWeight: '450', mb: 1 }}>City:</Typography>

            <Select
              fullWidth
              id="city"
              name="city"
              variant="outlined"
              value={cities?.length ? formik.values?.city : ''}
              onChange={formik.handleChange}
              disabled={!cities?.length}
              error={formik.touched.city && Boolean(formik.errors.city)}
              sx={{ mt: 2 }}
            >
              <MenuItem value="">Select City</MenuItem>
              {cities?.map((city) => (
                <MenuItem key={city.id} value={city.id}>
                  {city.name}
                </MenuItem>
              ))}
            </Select>

            {formik.touched.city && formik.errors.city ? (
              <Typography variant="caption" color="error">
                {formik.errors.city}
              </Typography>
            ) : null}
          </Grid>

          <Grid item xs={12} sm={6}>
            <Box sx={{ mt: 1.2, ml: 2 }}>
              <Typography sx={{ color: 'black', fontWeight: '450', mb: 1 }}>Active:</Typography>
              <RadioGroup
                sx={{ mt: 2.5 }}
                aria-label="isActive"
                name="is_active"
                value={formik.values?.is_active}
                onChange={(event) => {
                  formik.setFieldValue('is_active', event.target.value);
                  console.log('event value : ', event.target.value);
                }}
                row
              >
                <FormControlLabel value={true} control={<Radio color="primary" />} label="Yes" />
                <FormControlLabel value={false} control={<Radio color="primary" />} label="No" />
              </RadioGroup>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Typography sx={{ color: 'black', fontWeight: '450', mb: 1 }}>Company Logo:</Typography>
            <Box sx={{}}>
              <Box
                sx={{
                  width: '100px',
                  height: '100px',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  border: '2px solid #ccc',
                  position: 'relative',
                }}
              >
                <IconButton
                  component="label"
                  sx={{
                    position: 'absolute',
                    right: -5,
                    top: -5,
                    zIndex: 10,
                    bgcolor: '#ffffff',
                    '&:hover': { bgcolor: '#F0F0F0' },
                  }}
                >
                  <AddIcon />
                  <input type="file" style={{ display: 'none' }} onChange={handleImageChange} />
                </IconButton>

                <Avatar
                  alt="Uploaded"
                  src={formik.values?.logo?.url}
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover',
                  }}
                />
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Box>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', marginTop: 2 }}>
        <Button
          type="button"
          variant="outlined"
          size="large"
          sx={{ mr: 2, bgcolor: 'white', color: 'black', border: 'white' }}
          onClick={handleReset}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          variant="contained"
          size="large"
          color="primary"
          startIcon={<CheckIcon />}
        >
          {userId ? 'update' : 'add'}
        </Button>
      </Box>
    </form>
  );
};

export default AuthorizedServicePartnerForm;
