import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { DeviceManagementTableColDef } from '../utilities/helpers';
import DeviceManagementActionRenderer from './SystemManagementActionRenderer';
import { useEffect, useState } from 'react';
import { ListSystems } from 'src/ApiCalls/SystemMangementApiCalls';
const defaultColDef = {
  flex: 1,
  minWidth: 100,
  sortable: true,
  filter: true,
  resizable: true,
  wrapText: true,
  autoHeight: true,
  cellStyle: { display: 'flex', alignItems: 'center', fontFamily: 'Poppins, sans-serif' },
};
const frameworkComponents = {
  DeviceManagementActionRenderer,
};
const SystemManagementTable = ({ rows }) => {
  const [systemManagementData, setSystemManagementData] = useState(null);
  useEffect(() => {
    (async () => {
      let result = await ListSystems();

      setSystemManagementData(result);
    })();
  }, []);

  return (
    <div className="ag-theme-alpine" style={{ margin: '10px 0', height: '60vh' }}>
      <AgGridReact
        rowData={systemManagementData}
        defaultColDef={defaultColDef}
        columnDefs={DeviceManagementTableColDef}
        suppressScrollOnNewData={true}
        rowSelection="single"
        components={frameworkComponents}
      />
    </div>
  );
};

export default SystemManagementTable;
