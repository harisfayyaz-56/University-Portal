import { useRef } from 'react';
import styled from '@emotion/styled';
import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import LoadingButton from '@mui/lab/LoadingButton';
import Box from '@mui/material/Box';
import { AgGridReact } from 'ag-grid-react';
import StatusRenderer from '../../shared/StatusRenderer';
// import { uploadList } from './ImportUserHelpers';
import { ActionButtons } from 'src/shared/ImportActions';
import SendIcon from '@mui/icons-material/Send';

const defaultColDef = {
  flex: 1,
  minWidth: 100,
  sortable: true,
  resizable: true,
  editable: true,
  wrapHeaderText: true,
  autoHeaderHeight: true,
};

const frameworkComponents = {
  ActionButtons,

  StatusRenderer,
};

const ImportPartnerTable = ({ rows, setRowData, columnDefs }) => {
  // const [loading, setLoading] = useState(false);
  const agGridRef = useRef();
  // let skippedFieldCount = 0;
  // const dispatch = useDispatch();

  const handelSubmit = async (e) => {
    e.preventDefault();
    const rowData = [];
    const gridApi = agGridRef.current.api;

    gridApi.forEachNode((node) => {
      const nodeData = { ...node.data };
      if (columnDefs.find((def) => def.field === 'status')) {
        nodeData.is_active = nodeData.status?.toLowerCase() === 'active';
        delete nodeData['status'];
      }

      //if (nodeData.name && nodeData.phone & nodeData.email) {
      rowData.push(nodeData);
      //} else {
      //skippedFieldCount++;
      //}
    });
    // if (rowData.length) {
    //   // setLoading(true);
    //   const response = await uploadList(rowData);
    //   // setLoading(false);
    //   if (response) {
    //     if (response.status) {
    //       let message = response.message;
    //       if (skippedFieldCount) {
    //         message = message + ` Skipped ${skippedFieldCount} fields.`;
    //       }

    //       setRowData(null);

    //       // dispatch(
    //       //   setSnackbarObj({
    //       //     severity: 'success',
    //       //     message,
    //       //   }),
    //       // );
    //       console.log('fdsfdsfdsfds');
    //     } else {
    //       console.log('fdsfdsfdsfds');
    //       // dispatch(
    //       //   setSnackbarObj({
    //       //     severity: 'error',
    //       //     message: response.errors?.length
    //       //       ? response.errors[0].message
    //       //       : 'Name,Phone and Email fields are required',
    //       //   }),
    //       // );
    //     }
    //   } else {
    //     console.log('fdsfdsfdsfds');
    //     // dispatch(
    //     //   setSnackbarObj({
    //     //     severity: 'error',
    //     //     message: 'There was an error in uploading Partners.',
    //     //   }),
    //     // );
    //   }
    // } else {
    //   console.log('fdsfdsfdsfds');
    //   // dispatch(
    //   //   setSnackbarObj({
    //   //     severity: 'error',
    //   //     message: 'There are no partners navailable for import',
    //   //   }),
    //   // );
    // }
  };
  const handelReset = (e) => {
    e.preventDefault();
    setRowData(null);
  };

  return (
    <div style={{ margin: '10px 0' }}>
      <StyledGrid>
        <div className="ag-theme-alpine">
          <AgGridReact
            ref={agGridRef}
            rowData={rows}
            defaultColDef={defaultColDef}
            columnDefs={columnDefs}
            components={frameworkComponents}
            suppressScrollOnNewData={true}
          />
        </div>
      </StyledGrid>
      <Box
        component="form"
        onSubmit={handelSubmit}
        onReset={handelReset}
        sx={{ mt: 2 }}
        display="flex"
        justifyContent="end"
      >
        <Button variant="outlined" color="primary" type="reset" sx={{ mr: 2 }}>
          Cancel
        </Button>
        <LoadingButton
          variant="contained"
          color="primary"
          startIcon={<SendIcon />}
          // loading={loading}
          loadingPosition="start"
          type="submit"
          //disabled={loading}
        >
          Upload
        </LoadingButton>
      </Box>
    </div>
  );
};

export default ImportPartnerTable;

const StyledGrid = styled(Grid)(({ theme }) => ({
  '& .ag-root-wrapper': {
    height: '50vh',
    [theme.breakpoints.up('xl')]: {
      height: '40vh',
    },
    [theme.breakpoints.down('md')]: {
      height: '30vh',
    },
    [theme.breakpoints.down('sm')]: {
      height: '40vh',
    },
  },
}));
