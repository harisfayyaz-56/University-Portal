import React from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { viewSystemData } from '../utilities/constant';
import { ViewSystemtableColDef } from '../utilities/helpers';
import { Button, Typography, Box } from '@mui/material';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import BackButton from 'src/shared/BackButton';
import PageContainer from 'src/components/container/PageContainer';

const defaultColDef = {
  flex: 1,
  minWidth: 100,
  sortable: true,
  filter: true,
  resizable: true,
  wrapText: true,
  autoHeight: true,
  cellStyle: { display: 'flex', alignItems: 'center', fontFamily: 'Poppins, sans-serif' },
  wrapHeaderText: true,
  autoHeaderHeight: true,
};

const SystemManagmentDetails = () => {
  return (
    <PageContainer title="Devices" description="this is syestem view page">
      <Box
        component="div"
        display="flex"
        flexDirection={{ xs: 'column', sm: 'row' }}
        justifyContent={{ xs: 'flex-start', sm: 'space-between' }}
        alignItems={{ xs: 'start', sm: 'center' }}
      >
        <Box component="div" mb={{ xs: 2, sm: 0 }}>
          <Typography variant="h3">
            {' '}
            <BackButton /> System Statistics
          </Typography>
        </Box>
        <Box component="div">
          <Button variant="contained" startIcon={<ArrowDownwardIcon />} sx={{ mr: 2 }}>
            Download
          </Button>
        </Box>
      </Box>

      <Box sx={{ mt: 6 }}>
        <div className="ag-theme-alpine" style={{ margin: '10px 0', height: '60vh' }}>
          <AgGridReact
            rowData={viewSystemData}
            defaultColDef={defaultColDef}
            columnDefs={ViewSystemtableColDef}
            suppressScrollOnNewData={true}
          />
        </div>
      </Box>
    </PageContainer>
  );
};

export default SystemManagmentDetails;
