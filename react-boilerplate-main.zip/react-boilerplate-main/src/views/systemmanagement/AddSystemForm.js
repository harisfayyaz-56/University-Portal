import React, { useState, useEffect, useCallback } from 'react';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import MenuItem from '@mui/material/MenuItem';
import { Box, Typography, Button, Select } from '@mui/material';
import CheckIcon from '@mui/icons-material/Check';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { ListPartners } from 'src/ApiCalls/AuthorizedServicePartnerApiCalls';
import { useLocation, useNavigate, useParams } from 'react-router';
import { createSystem, editSystem } from 'src/ApiCalls/SystemMangementApiCalls';

const AddSystemForm = () => {
  const [authorizedPartners, setAuthorizedPartners] = useState([]);
  const [systemData, setSystemData] = useState({});
  const { state } = useLocation();
  const { id: systemID } = useParams();

  const getSystemData = useCallback((data) => {
    setSystemData(data);
  }, []);
  const initialValues = {
    modelNumber: systemData?.modelNumber ?? '',
    authorizedPartner: systemData?.servicePartner ?? '',
    serialNumber: systemData?.serialNumber ?? '',
    macAddress: systemData?.MACAddress ?? '',
  };
  const navigate = useNavigate();
  const validationSchema = Yup.object().shape({
    modelNumber: Yup.string()
      .max(50, 'Model number must be at most 50 characters')
      .required('Model number is required'),
    authorizedPartner: Yup.string()
      .max(50, 'Authorized partner must be at most 50 characters')
      .required('Authorized partner is required'),
    serialNumber: Yup.string()
      .max(50, 'Serial number must be at most 50 characters')
      .required('Serial number is required'),
    macAddress: Yup.string()
      .max(50, 'MAC address must be at most 50 characters')
      .required('MAC address is required'),
  });

  const handleForm = async (values) => {
    let response;
    if (systemID) {
      response = await editSystem(values, systemID);
    } else {
      response = await createSystem(values);
    }
    if (response) {
      navigate('/system-managment');
    }
  };

  const formik = useFormik({
    initialValues,
    validationSchema,
    enableReinitialize: true,
    onSubmit: (values) => {
      handleForm(values);
    },
  });
  const loadMoreItems = (e) => {
    const bottom = e.target.scrollHeight === e.target.scrollTop + e.target.clientHeight;
    if (bottom) {
    }
  };

  const handleReset = () => {
    navigate('/system-managment');
  };

  useEffect(() => {
    const fetchAuthorizedPartners = async () => {
      try {
        const partners = await ListPartners();
        setAuthorizedPartners(partners);
      } catch (error) {
        console.error('Listing failed:', error);
      }
    };
    if (systemID) {
      getSystemData(state);
    }

    fetchAuthorizedPartners();
  }, [getSystemData, systemID, state]);

  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <Box
          sx={{
            bgcolor: '#ffffff',
            marginTop: { xs: 4, sm: 8 },
            padding: { xs: 3, sm: 6 },
            borderRadius: 6,
            position: 'relative',
          }}
        >
          <Typography variant="h3"> {!systemID ? 'Add System' : 'Update System'}</Typography>
          <Grid container spacing={2} sx={{ marginTop: 2 }}>
            <Grid item xs={12} sm={6}>
              <Typography sx={{ color: 'black', fontWeight: '450', mb: 1 }}>
                Model Number:
              </Typography>
              <TextField
                fullWidth
                id="modelNumber"
                name="modelNumber"
                variant="outlined"
                value={formik.values.modelNumber}
                onChange={formik.handleChange}
                error={formik.touched.modelNumber && Boolean(formik.errors.modelNumber)}
                helperText={formik.touched.modelNumber && formik.errors.modelNumber}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography sx={{ color: 'black', fontWeight: '450', mb: 1 }}>
                Authorized Service Partner:
              </Typography>
              <Select
                fullWidth
                MenuProps={{
                  PaperProps: {
                    onScroll: loadMoreItems,
                  },
                  style: {
                    maxHeight: 500,
                  },
                }}
                id="authorizedPartner"
                name="authorizedPartner"
                variant="outlined"
                value={authorizedPartners.length ? formik.values.authorizedPartner : ''}
                onChange={formik.handleChange}
                error={formik.touched.authorizedPartner && Boolean(formik.errors.authorizedPartner)}
              >
                {authorizedPartners?.map((partner) => (
                  <MenuItem key={partner.id} value={partner.id}>
                    {partner.company_name}
                  </MenuItem>
                ))}
              </Select>
              {formik.touched.authorizedPartner && formik.errors.authorizedPartner ? (
                <Typography variant="caption" color="error">
                  {formik.errors.authorizedPartner}
                </Typography>
              ) : null}
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography sx={{ color: 'black', fontWeight: '450', mb: 1 }}>
                Serial Number:
              </Typography>
              <TextField
                fullWidth
                id="serialNumber"
                name="serialNumber"
                variant="outlined"
                value={formik.values.serialNumber}
                onChange={formik.handleChange}
                error={formik.touched.serialNumber && Boolean(formik.errors.serialNumber)}
                helperText={formik.touched.serialNumber && formik.errors.serialNumber}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography sx={{ color: 'black', fontWeight: '450', mb: 1 }}>
                MAC Address:
              </Typography>
              <TextField
                fullWidth
                id="macAddress"
                name="macAddress"
                variant="outlined"
                value={formik.values.macAddress}
                onChange={formik.handleChange}
                error={formik.touched.macAddress && Boolean(formik.errors.macAddress)}
                helperText={formik.touched.macAddress && formik.errors.macAddress}
              />
            </Grid>
          </Grid>
        </Box>
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', marginTop: 2 }}>
          <Button
            type="button"
            variant="outlined"
            size="large"
            onClick={handleReset}
            sx={{ mr: 2 }}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            variant="contained"
            size="large"
            startIcon={<CheckIcon />}
            color="primary"
          >
            {!systemID ? 'Add ' : 'Update '}
          </Button>
        </Box>
      </form>
    </>
  );
};

export default AddSystemForm;
