import React from 'react';
import { Typography, Box, Button } from '@mui/material';
import PageContainer from 'src/components/container/PageContainer';
import { Link } from 'react-router-dom';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
import SystemManagementTable from './SystemManagementTable';
const SystemManagement = () => {

  return (
    <PageContainer title="System" description="this is Device listing page">
      <Box
        component="div"
        display="flex"
        flexDirection={{ xs: 'column', sm: 'row' }}
        justifyContent={{ xs: 'flex-start', sm: 'space-between' }}
        alignItems={{ xs: 'start', sm: 'end' }}
      >
        <Box component="div" mb={{ xs: 2, sm: 0 }}>
          <Typography variant="h3"> System</Typography>
        </Box>
        <Box component="div">
          <Button
            size="medium"
            sx={{ marginRight: 1 }}
            color="primary"
            variant="contained"
            startIcon={<AddOutlinedIcon />}
            to="/system-managment/bulk-upload"
            component={Link}
          >
            Bulk Upload
          </Button>
          <Button
            size="medium"
            component={Link}
            to="/system-managment/add-system"
            color="primary"
            variant="contained"
            startIcon={<AddOutlinedIcon />}
          >
            Add System
          </Button>
        </Box>
      </Box>
      <Box sx={{ mt: 6 }}>
        <SystemManagementTable />
      </Box>
    </PageContainer>
  );
};

export default SystemManagement;
