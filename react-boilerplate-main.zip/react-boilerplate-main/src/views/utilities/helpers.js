export const LoginSliders = [
  {
    image: '/images/auth/connectwithanydevice.png',
    name: 'Connect with any device.',
    description: 'Everything you need is an internet connection.',
  },
  {
    image: '/images/auth/joinus.png',
    name: 'Join Us',
    description: 'Just go through the boring process of creating an account.',
  },
  {
    image: '/images/auth/otp.png',
    name: '2 Factor Security',
    description: "OTP is received during login to ensure exclusive access to the user's account.",
  },
];

export const BesiAdminManagmentTableColDef = [
  {
    headerName: 'ID',
    field: 'id',
    minWidth: 80,
    maxWidth: 80,
  },
  {
    headerName: 'FIRST NAME',
    field: 'first_name',
    minWidth: 200,
  },
  {
    headerName: 'LAST NAME',
    field: 'last_name',
    minWidth: 200,
  },
  {
    headerName: 'EMAIL ADDRESS',
    field: 'email',
    minWidth: 300,
  },
  {
    headerName: 'ACCESS LEVEL',
    field: 'type',
    minWidth: 200,
  },
  { headerName: 'Status', field: 'is_active', cellRenderer: 'StatusRenderer', minWidth: 150 },
  {
    headerName: 'ACTIONS',
    cellRenderer: 'BesiAdminManagementActionRenderer',
    minWidth: 150,
  },
];

export const AuthorizedServicePartnerColumnDefs = [
  { headerName: 'Company Name', field: 'company_name', minWidth: 250 },
  { headerName: 'Company Phone No', field: 'phone_number', minWidth: 250 },
  { headerName: 'Company Email', field: 'email', minWidth: 250 },
  { headerName: 'Country', field: 'country' },
  { headerName: 'State', field: 'state' },
  { headerName: 'City', field: 'city' },
  { headerName: 'Status', field: 'is_active', cellRenderer: 'StatusRenderer', minWidth: 150 },
  { headerName: 'Action', field: 'action', cellRenderer: 'ActionRenderer', minWidth: 150 },
];
export const AuthorizedServicePartnerColumnDefs1 = [
  { headerName: 'Company Name', field: 'company_name' },
  { headerName: 'Company Phone No', field: 'phone_number' },
  { headerName: 'Company Email', field: 'email' },
  { headerName: 'Country', field: 'country' },
  { headerName: 'State', field: 'state' },
  { headerName: 'Address', field: 'address' },
  { headerName: 'Street', field: 'street' },
  { headerName: 'Postal Code', field: 'postal_code' },
  { headerName: 'City', field: 'city' },
  { headerName: 'Status', field: 'is_active', cellRenderer: 'StatusRenderer' },
  { headerName: 'Action', field: 'action', cellRenderer: 'ActionButtons' },
];

export const DeviceManagementTableColDef = [
  {
    headerName: 'SERIAL NUMBER',
    field: 'serialNumber',
    minWidth: 200,
  },
  {
    headerName: 'SERVICE PARTNER',
    field: 'servicePartner',
    minWidth: 200,
  },

  {
    headerName: 'MODEL NUMBER',
    field: 'modelNumber',
    minWidth: 200,
  },
  {
    headerName: 'MAC ADDRESS',
    field: 'MACAddress',
    minWidth: 200,
  },

  {
    headerName: 'FIRST NAME',
    field: 'firstname',
    minWidth: 150,
  },
  {
    headerName: 'LAST NAME',
    field: 'lastName',
    minWidth: 150,
  },

  {
    headerName: 'DEVICE NAME',
    field: 'deviceName',
    minWidth: 200,
  },

  {
    headerName: 'SYSTEM STATUS',
    field: 'systemStatus',
    minWidth: 200,
  },
  {
    headerName: 'BATTERY CAPACITY',
    field: 'batteryCapacity',
    minWidth: 200,
  },

  {
    headerName: 'WIFI MODULE ADDRESS',
    field: 'wifiModuleAddress',
    minWidth: 200,
  },

  {
    headerName: 'ACTIVATION DATE',
    field: 'activationDate',
    minWidth: 200,
  },
  {
    headerName: 'UPLOAD DATE',
    field: 'uploadDate',
    minWidth: 200,
  },

  {
    headerName: 'ACTIONS',
    cellRenderer: 'DeviceManagementActionRenderer',
    minWidth: 150,
  },
];
export const DeviceManagementTableColDef1 = [
  {
    headerName: 'DEVICE NAME',
    field: 'deviceName',
    minWidth: 300,
  },
  {
    headerName: 'SERIAL NUMBER',
    field: 'serialNumber',
    minWidth: 150,
  },
  {
    headerName: 'SERVICE PARTNER Email',
    field: 'authorizedServicePartnerEmail',
    minWidth: 200,
  },
  {
    headerName: 'CUSTOMER NAME',
    field: 'customerName',
    minWidth: 200,
  },
  {
    headerName: 'MODEL NUMBER',
    field: 'modelNumber',
    minWidth: 150,
  },
  {
    headerName: 'WIFI MODULE ADDRESS',
    field: 'wifiModuleAddress',
    minWidth: 300,
  },
  {
    headerName: 'MAC ADDRESS',
    field: 'MACAddress',
    minWidth: 300,
  },
  {
    headerName: 'ACTIVATION DATE',
    field: 'activationDate',
    minWidth: 300,
  },
  {
    headerName: 'UPLOAD DATE',
    field: 'uploadDate',
    minWidth: 300,
  },
  {
    headerName: 'BATTERY STATUS',
    field: 'batteryStatus',
    minWidth: 300,
  },
  {
    headerName: 'Actions',
    cellRenderer: 'ActionButtons',
    minWidth: 300,
  },
];
export const ViewSystemtableColDef = [
  {
    headerName: 'Input Voltage',
    field: 'inputVoltage',
    minWidth: 150,
  },
  {
    headerName: 'Input Fault Voltage',
    field: 'inputFaultVoltage',
    minWidth: 150,
  },
  {
    headerName: 'Output Voltage',
    field: 'outputVoltage',
    minWidth: 150,
  },
  {
    headerName: 'Output Current',
    field: 'outputCurrent',
    minWidth: 150,
  },
  {
    headerName: 'Output Frequency',
    field: 'outputFrequency',
    minWidth: 150,
  },
  {
    headerName: 'Battery Voltage',
    field: 'batteryVoltage',
    minWidth: 150,
  },
  {
    headerName: 'Temperature',
    field: 'temperature',
    minWidth: 150,
  },
  {
    headerName: 'Utility Fail',
    field: 'utilityFail',
    minWidth: 150,
  },
  {
    headerName: 'Battery Low',
    field: 'batteryLow',
    minWidth: 150,
  },
  {
    headerName: 'UPS Failed',
    field: 'upsFailed',
    minWidth: 100,
  },
  {
    headerName: 'UPS Normal',
    field: 'upsNormal',
    minWidth: 100,
  },
  {
    headerName: 'UPS Fanlock',
    field: 'upsFanlocak',
    minWidth: 100,
  },
  {
    headerName: 'UPS Overload',
    field: 'upsOverload',
    minWidth: 130,
  },
  {
    headerName: 'UPS Short Circuit ',
    field: 'upsShortCircuit',
    minWidth: 100,
  },
  {
    headerName: 'UPS Bad Battery ',
    field: 'upsBadBattery',
    minWidth: 100,
  },
  {
    headerName: 'Inverter Charging',
    field: 'inverterCharging',
    minWidth: 130,
  },
  {
    headerName: 'Inverter Not Charging',
    field: 'inverterNotCharging',
    minWidth: 130,
  },
];
