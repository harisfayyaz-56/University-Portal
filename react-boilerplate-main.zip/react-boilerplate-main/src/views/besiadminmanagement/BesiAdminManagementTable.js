import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { BesiAdminManagmentTableColDef } from '../utilities/helpers';
import BesiAdminManagementActionRenderer from './BesiAdminManagementActionRenderer';
import StatusRenderer from '../../shared/StatusRenderer';
const defaultColDef = {
  flex: 1,
  minWidth: 100,
  sortable: true,
  filter: true,
  resizable: true,
  wrapText: true,
  autoHeight: true,
  cellStyle: { display: 'flex', alignItems: 'center', fontFamily: 'Poppins, sans-serif' },
};
const frameworkComponents = {
  BesiAdminManagementActionRenderer,
  StatusRenderer,
};

const BesiAdminManagementTable = ({ rows }) => {
  

  return (
    <div className="ag-theme-alpine" style={{ margin: '10px 0'}}>
      <AgGridReact
        rowData={rows}
        defaultColDef={defaultColDef}
        columnDefs={BesiAdminManagmentTableColDef}
        suppressScrollOnNewData={true}
        rowSelection="multiple"
        components={frameworkComponents}
        domLayout='autoHeight'
      />
    </div>
  );
};

export default BesiAdminManagementTable;
