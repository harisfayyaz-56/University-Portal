// import { Typography, Box } from '@mui/material';
// import PageContainer from 'src/components/container/PageContainer';
// import BackButton from 'src/shared/BackButton';
// import TermsAndConditionsForm from './TermsAndConditionsForm';

// const TermsAndConditions = () => {
//   return (
//     <PageContainer title="Warranty Information" description="this is Warranty Information page">
//       <Box
//         component="div"
//         display="flex"
//         flexDirection={{ xs: 'column', sm: 'row' }}
//         justifyContent={{ xs: 'flex-start', sm: 'space-between' }}
//         alignItems={{ xs: 'start', sm: 'center' }}
//       >
//         <Box component="div" mb={{ xs: 2, sm: 0 }}>
//           <BackButton />
//           <Typography variant="h3">Warranty/Terms & Conditions</Typography>
//         </Box>
//       </Box>
//       <TermsAndConditionsForm />
//     </PageContainer>
//   );
// };

// export default TermsAndConditions;
