// import React, { useState } from 'react';
// import { Box, Button, Typography } from '@mui/material';
// // import CheckIcon from '@mui/icons-material/Check';
// import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
// import CloudUploadIcon from '@mui/icons-material/CloudUpload';
// import DeleteIcon from '@mui/icons-material/Delete';
// import FolderIcon from '@mui/icons-material/Folder';

// const TermsAndConditionsForm = () => {
//   const [warrantyFile, setWarrantyFile] = useState(null);
//   const [termsFile, setTermsFile] = useState(null);

//   const handleWarrantyFileChange = (event) => {
//     setWarrantyFile(event.target.files[0]);
//   };

//   const handleTermsFileChange = (event) => {
//     setTermsFile(event.target.files[0]);
//   };

//   const handleRemove = (type) => {
//     if (type === 'warranty') {
//       setWarrantyFile(null);
//     } else if (type === 'terms') {
//       setTermsFile(null);
//     }
//   };

//   return (
//     <>
//       <Box
//         sx={{
//           bgcolor: '#ffffff',
//           marginTop: { xs: 4, sm: 8 },
//           padding: { xs: 3, sm: 6 },
//           position: 'relative',
//           display: 'flex',
//           alignItems: 'center',
//         }}
//       >
//         <FolderIcon sx={{ mr: 2, color: '#FFC027' }} />
//         <Typography variant="h6" sx={{ flexGrow: 1 }}>
//           Warranty Document
//         </Typography>
//         {/* <Typography variant="body1" sx={{ mr: 2 }}>
//           {warrantyFile && warrantyFile.name}
//         </Typography> */}
//         <Button
//           variant="contained"
//           startIcon={<DeleteIcon />}
//           disabled={!warrantyFile}
//           onClick={() => handleRemove('warranty')}
//           sx={{ mr: 2 }}
//         >
//           Remove
//         </Button>
//         <Button variant="contained" startIcon={<ArrowDownwardIcon />} sx={{ mr: 2 }}>
//           Download
//         </Button>
//         <label htmlFor="warranty-upload-file">
//           <input
//             type="file"
//             id="warranty-upload-file"
//             accept="image/*"
//             style={{ display: 'none' }}
//             onChange={handleWarrantyFileChange}
//           />
//           <Button variant="contained" startIcon={<CloudUploadIcon />} component="span">
//             {warrantyFile ? 'Reupload' : 'Upload'}
//           </Button>
//         </label>
//       </Box>
//       <Box
//         sx={{
//           bgcolor: '#ffffff',
//           marginTop: { xs: 2, sm: 2 },
//           padding: { xs: 3, sm: 6 },
//           position: 'relative',
//           display: 'flex',
//           alignItems: 'center',
//         }}
//       >
//         <FolderIcon sx={{ mr: 2, color: '#FFC027' }} />
//         <Typography variant="h6" sx={{ flexGrow: 1 }}>
//           Terms & Conditions Document
//         </Typography>
//         {/* <Typography variant="body1" sx={{ mr: 2 }}>
//           {termsFile && termsFile.name}
//         </Typography> */}
//         <Button
//           variant="contained"
//           startIcon={<DeleteIcon />}
//           disabled={!termsFile}
//           onClick={() => handleRemove('terms')}
//           sx={{ mr: 2 }}
//         >
//           Remove
//         </Button>
//         <Button variant="contained" startIcon={<ArrowDownwardIcon />} sx={{ mr: 2 }}>
//           Download
//         </Button>
//         <label htmlFor="terms-upload-file">
//           <input
//             type="file"
//             id="terms-upload-file"
//             accept="image/*"
//             style={{ display: 'none' }}
//             onChange={handleTermsFileChange}
//           />
//           <Button variant="contained" startIcon={<CloudUploadIcon />} component="span">
//             {termsFile ? 'Reupload' : 'Upload'}
//           </Button>
//         </label>
//       </Box>
//       {/* <Box sx={{ display: 'flex', justifyContent: 'flex-end', marginTop: 2 }}>
//         <Button variant="contained" size="large" startIcon={<CheckIcon />} color="primary">
//           Update
//         </Button>
//       </Box> */}
//     </>
//   );
// };

// export default TermsAndConditionsForm;
