import { Box, Button, Grid, MenuItem, TextField, Typography } from '@mui/material';
import CheckIcon from '@mui/icons-material/Check';
import { SettingsDataListing } from 'src/ApiCalls/SettingsApiCalls';
import { SettingsDataUpdate } from 'src/ApiCalls/SettingsApiCalls';
import { useState, useEffect } from 'react';

const batteryPercentOptions = [5, 10, 15, 20, 25, 30];
const batteryCapacityOptions = [
  { label: 'Yes', value: 1 },
  { label: 'No', value: 0 },
];

const SettingsFormContainer = () => {
  const [batteryNotify, setBatteryNotify] = useState('');
  const [stateChangeNotify, setStateChangeNotify] = useState('');
  const [settingsId, setSettingsId] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await SettingsDataListing();
        if (response) {
          setBatteryNotify(response.notify_when_battery_is);
          setSettingsId(response.id);
          setStateChangeNotify(response.notify_when_battery_state_change);
        }
      } catch (error) {
        console.error('Error fetching settings data:', error);
      }
    };

    fetchData();
  }, []);

  const handleBatteryNotifyChange = (event) => {
    setBatteryNotify(event.target.value);
  };

  const handleStateChangeNotifyChange = (event) => {
    setStateChangeNotify(event.target.value);
  };

  const handleUpdate = async () => {
    await SettingsDataUpdate({ batteryNotify, stateChangeNotify }, settingsId);
  };

  return (
    <>
      <Box
        sx={{
          bgcolor: '#ffffff',
          marginTop: { xs: 4, sm: 8 },
          padding: { xs: 3, sm: 6 },
          borderRadius: 6,
          position: 'relative',
        }}
      >
        <Typography variant="h3">Device Notifications</Typography>

        <Grid container spacing={2} sx={{ marginTop: 2 }}>
          <Grid item xs={12} sm={6}>
            <Typography sx={{ color: 'black', fontWeight: '450', mb: 1 }}>
              Trigger Notification when Battery Capacity is:
            </Typography>
            <TextField
              select
              fullWidth
              variant="outlined"
              value={batteryNotify}
              id="batteryPercent"
              onChange={handleBatteryNotifyChange}
            >
              {batteryPercentOptions.map((option) => (
                <MenuItem key={option} value={option}>
                  {option}%
                </MenuItem>
              ))}
            </TextField>
          </Grid>

          <Grid item xs={12} sm={6}>
            <Typography sx={{ color: 'black', fontWeight: '450', mb: 1 }}>
              Trigger Notification if System State Changes{' '}
            </Typography>
            <TextField
              select
              fullWidth
              variant="outlined"
              value={stateChangeNotify}
              id="batteryCapacity"
              onChange={handleStateChangeNotifyChange}
            >
              {batteryCapacityOptions.map((option, index) => (
                <MenuItem key={index} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </TextField>
          </Grid>
        </Grid>
      </Box>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', marginTop: 2 }}>
        <Button
          variant="contained"
          size="large"
          startIcon={<CheckIcon />}
          color="primary"
          onClick={handleUpdate}
        >
          Update
        </Button>
      </Box>
    </>
  );
};

export default SettingsFormContainer;
