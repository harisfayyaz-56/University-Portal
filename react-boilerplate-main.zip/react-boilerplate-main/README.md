# React-Admin BoilerPlate

#### Admin Panel

```
npm install
```

```
npm start
```
